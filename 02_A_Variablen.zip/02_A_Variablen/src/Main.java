public class Main {
    public static void main(String[] args) {
        //--------------------------------------------------------------------------------------------------------------
        // Naming

        // Which are valid variable names and which are not?
        // Try to determine what is valid and what is not without uncommenting the code.
        // If something is not valid, write a comment explaining why it is not valid.

        // Example:
        // int myVariable; // Valid
        // int %myVariable; // Not Valid, starts with a special character.


        // int 1stNumber;

        // int firstNumber;

        // int tryThisNumber;

        // int _myNumber;

        // int int;

        // int _number_;

        // int i;

        // int number1;

        // int .product;

        //--------------------------------------------------------------------------------------------------------------


        //--------------------------------------------------------------------------------------------------------------
        // Naming convention

        // Which are recommended variable names and which are not?

        // Example:
        // int myVariable; // recommended
        // int _myVariable; // not recommended, starts with a special character
        // int g; // not recommended, depending on the context, it can make sense. E.g. in the context of gravitational acceleration

        int number1;
        int speed;
        int JustANUmber;
        int justAnotherNumber;
        int _weather;
        int _Id;
        int $Money;
        int moneyinthebankaccount;
        int aLotOfmoneyonbankAccount;
        int circumstanceEarthInKM;
        int circumstanceEarth_KM;

        //--------------------------------------------------------------------------------------------------------------


        //--------------------------------------------------------------------------------------------------------------
        // Declaration and initialization of variables

        // Add the appropriate data type before the variable name, so, that it becomes a valid declaration and initialization.
        // (Variable names are in german to not reveal the result)

        meineGleitkommaZahl = 23.5f;

        meineSehrKleineGanzzahl = 50;

        meinUnicodeZeichen = '\u003D';

        meineKleineGanzzahl = 200;

        meinBuchstabe = 'B';

        meineNegativeGleitkommaZahl = -14.612f;

        meineGrosseGleitkommaZahl = 50.1234567890123d;

        meinWahrheitswert1 = false;

        meineNormaleGanzzahl = 50_000;

        meineGrosseGanzzahl = 123_456_789_012_345L;

        meinWahrheitswert2 = true;


        //--------------------------------------------------------------------------------------------------------------


        //--------------------------------------------------------------------------------------------------------------
        // Keyword final

        // Based on the variable name/value, decide if the keyword "final" is suitable or not.
        // If it is suitable, apply the recommended naming convention for variables with the "final" keyword.
        // Write -why- you decided to either mark it as final or not.


        int monyInBankAccount = 100_000;

        short myBirthyear = 2001;

        byte amountOfMonths = 12;

        float gravityForce = 9.81f;

        byte amountOfMinutesPerHour = 60;

        short amountOfSecondsPerHour = 3600;

        float pi = 3.14159f;

        short amountOfStudents = 167;

        //--------------------------------------------------------------------------------------------------------------
    }
}