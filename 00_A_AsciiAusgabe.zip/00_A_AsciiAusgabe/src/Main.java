public class Main {
    public static void main(String[] args) {

        /*
         Try to output "JAVA" with Ascii-art.
         Use the "System.out.println" command.
         Print your result on the console.
         The first letter "J" is already done as an example.
        */

        System.out.println("  *******         **         *           *            **       ");
        System.out.println("        *        *  *         *         *            *  *      ");
        System.out.println("        *       *    *         *       *            *    *     ");
        System.out.println("        *      ********         *     *            ********    ");
        System.out.println("  *     *     *        *         *   *            *        *   ");
        System.out.println("  *     *    *          *         * *            *          *  ");
        System.out.println("  *******   *            *         *            *            * ");
        System.out.println("");
        System.out.println("");
        System.out.println("                           *            *                       ");
        System.out.println("                          ***          ***                      ");
        System.out.println("                         *******************                    ");
        System.out.println("                        *********************                   ");
        System.out.println("                       ****  **********  *****                  ");
        System.out.println("                      *************************                 ");
        System.out.println("                       *********** ***********                  ");
        System.out.println("                        ***** ********** *****                  ");
        System.out.println("                         *******     ********                   ");
        System.out.println("                          ******************                    ");
      

        // Example for the letter "J":
        //    *******
        //          *
        //          *
        //          *
        //    *     *
        //    *     *
        //    *******


        // After you successfully printed "JAVA" as Ascii-art on the console, try
        // to implement your own ascii art!
        // It can be your name, your hobby, your favorite food or even some fancy art!
        // Feel free to get inspiration on the internet!

        // Of course, also print it out on the console.
    }
}